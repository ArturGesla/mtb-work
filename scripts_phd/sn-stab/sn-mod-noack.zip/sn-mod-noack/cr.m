function c=cr(n,m) 
if (n==m)
c=1;
else
c=0;%(1-(-1)^(abs(n-m)))/pi/(n-m);
end
end
