function s=sgn(x)
if(x<0)
    s=-1;
else
    s=1;
end
end